/*-----------------------------------------------------------------------------
    Name: init_script
    Recorded By: netstorm
    Date of recording: 10/03/2016 02:33:05
    Flow details:
    Build details: 4.1.6 (build# 20)
    Modification History:
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

int init_script()
{
    return 0;
}
