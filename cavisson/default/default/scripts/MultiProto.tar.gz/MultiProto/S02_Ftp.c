#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ns_string.h"

void S02_Ftp()
{
	
	ns_start_transaction("Ftp_Get");
     ns_ftp_get("Get",
	   "FTP_SERVER=216.66.23.198:21",
        "USER_ID={Username}",
        "PASSWORD={Password}",
        "PASSIVE=Y",
        "FILE=Websrv.txt"
        
    );
    ns_end_transaction("Ftp_Get", NS_AUTO_STATUS);
    ns_page_think_time(10.422);

     ns_start_transaction("Ftp_Put");
     ns_ftp_put("Put",
        "FTP_SERVER=216.66.23.198:21",
        "USER_ID={Username}",
        "PASSWORD={Password}",
        "PASSIVE=Y",
        "TYPE=I",
         "FILE=/home/cavisson/work/workspace/admin/default/cavisson/default/default/scripts/ftp_post/ftp_put.txt"
    );
    ns_end_transaction("Ftp_Put", NS_AUTO_STATUS);
    ns_page_think_time(10.422);
}
